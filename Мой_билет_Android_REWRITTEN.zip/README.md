# Мой билет

Восстановлено из предоставленного исходного кода Base44.

## Сборка web
npm install
npm run build

## Android
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
npx cap sync android

Для APK: Android Studio → Build → Build APK(s).

Base44 auth/entities заменены локальным адаптером в src/api/base44Client.js, потому что в исходном файле нет секретов/конфигурации Base44.
