import React from "react";
import { Ticket, History as HistoryIcon, CreditCard, Menu } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";

const items = [
  { label: "Мой билет", icon: Ticket, key: "ticket", path: "/" },
  { label: "История", icon: HistoryIcon, key: "history", path: "/history" },
  { label: "Оплата", icon: CreditCard, key: "payment", path: "/payment" },
  { label: "Меню", icon: Menu, key: "menu", path: "/menu" },
];

export default function BottomNav({ active }) {
  const navigate = useNavigate();
  const location = useLocation();
  const current = active ?? items.find((i) => i.path === location.pathname)?.key;

  return (
    <nav className="bg-white/90 backdrop-blur-lg border-t border-slate-100 pb-[env(safe-area-inset-bottom)]">
      <div className="flex items-stretch justify-around px-2 pt-2 pb-1.5">
        {items.map(({ label, icon: Icon, key, path }) => {
          const isActive = current === key;
          return (
            <button type="button" key={key} onClick={() => navigate(path)} className="flex flex-col items-center gap-1 flex-1 py-1.5 rounded-xl transition-colors">
              <Icon className={cn("h-6 w-6 transition-colors", isActive ? "text-violet-600" : "text-slate-400")} strokeWidth={isActive ? 2.4 : 2} />
              <span className={cn("text-[11px] leading-none transition-colors", isActive ? "text-violet-600 font-semibold" : "text-slate-400")}>{label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
