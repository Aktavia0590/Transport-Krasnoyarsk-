import React from "react";
import { MemoryRouter, Routes, Route, useLocation } from "react-router-dom";
import Home from "./pages/Home";
import History from "./pages/History";
import Payment from "./pages/Payment";
import Menu from "./pages/Menu";
import Scan from "./pages/Scan";
import { Toaster } from "./components/ui/toaster";

class ErrorBoundary extends React.Component {
  state = { error: null };
  static getDerivedStateFromError(error) { return { error }; }
  render() {
    if (this.state.error) {
      return (
        <div className="min-h-[100dvh] flex flex-col items-center justify-center bg-[#f9faff] px-6 text-center">
          <h2 className="text-xl font-bold text-[#333]">Не удалось открыть экран</h2>
          <p className="mt-2 max-w-sm text-sm text-[#777]">Попробуйте открыть приложение ещё раз.</p>
          <button onClick={() => window.location.reload()} className="mt-5 rounded-xl bg-violet-600 px-5 py-3 font-semibold text-white">Перезапустить</button>
        </div>
      );
    }
    return this.props.children;
  }
}

function ScrollToTop() {
  const { pathname } = useLocation();
  React.useEffect(() => window.scrollTo(0, 0), [pathname]);
  return null;
}

function NotFound() {
  return (
    <div className="min-h-[100dvh] flex items-center justify-center bg-[#f9faff]">
      <button onClick={() => window.history.back()} className="rounded-xl bg-violet-600 px-5 py-3 font-semibold text-white">Назад</button>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <MemoryRouter initialEntries={["/"]}>
        <ScrollToTop />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/history" element={<History />} />
          <Route path="/payment" element={<Payment />} />
          <Route path="/menu" element={<Menu />} />
          <Route path="/scan" element={<Scan />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </MemoryRouter>
      <Toaster />
    </ErrorBoundary>
  );
}
