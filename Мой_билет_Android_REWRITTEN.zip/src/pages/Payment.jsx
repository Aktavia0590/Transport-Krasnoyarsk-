import React from "react";
import { CreditCard, Plus } from "lucide-react";
import BottomNav from "@/components/BottomNav";

function SberLogo() {
  return (
    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-white shadow-sm overflow-hidden">
      <svg viewBox="0 0 32 32" className="h-6 w-6">
        <circle cx="16" cy="16" r="13" fill="none" stroke="#21A038" strokeWidth="3" />
        <circle cx="16" cy="16" r="8" fill="none" stroke="#21A038" strokeWidth="3" />
        <circle cx="16" cy="16" r="3" fill="#21A038" />
      </svg>
    </div>
  );
}

export default function Payment() {
  return (
    <div className="min-h-[100dvh] bg-[#f3f2fa] flex flex-col overflow-hidden">
      <header className="px-5 pt-6 pb-2">
        <h1 className="text-xl font-semibold text-[#2c2a38]">Оплата</h1>
      </header>

      <main className="relative flex-1 overflow-y-auto px-5 pb-40">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -top-10 -right-20 h-64 w-64 rounded-full bg-[#e8e7f5] blur-3xl opacity-80" />
          <div className="absolute bottom-0 -left-24 h-72 w-72 rounded-full bg-[#e8e7f5] blur-3xl opacity-70" />
        </div>

        <div className="relative z-10">
          <h2 className="text-base font-medium text-[#2c2a38] mt-2 mb-3">
            Ваши способы оплаты
          </h2>

          <div className="flex items-center gap-3 rounded-2xl bg-white/80 backdrop-blur p-3.5 shadow-sm shadow-violet-100/40">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-violet-50">
              <CreditCard className="h-6 w-6 text-violet-500" strokeWidth={1.8} />
            </div>
            <span className="flex-1 font-semibold text-[#333333]">Сбербанк</span>
            <SberLogo />
          </div>

          <button className="mt-2.5 flex w-full items-center gap-3 rounded-2xl bg-white/60 p-3.5 text-left">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-violet-50">
              <Plus className="h-6 w-6 text-violet-500" strokeWidth={2} />
            </div>
            <span className="font-medium text-[#666666]">Добавить карту</span>
          </button>
        </div>
      </main>

      <div className="fixed inset-x-0 bottom-0 z-20">
        <div className="px-5 pb-3 pt-1 bg-gradient-to-t from-[#f3f2fa] via-[#f3f2fa] to-transparent">
          <button className="w-full rounded-full bg-gradient-to-r from-violet-700 to-orange-400 py-4 text-center text-sm font-bold tracking-wide text-white shadow-lg shadow-violet-300/40 active:scale-[0.98] transition-transform">
            ПОДКЛЮЧИТЬ БАНКОВСКИЙ СЧЕТ
          </button>
        </div>
        <BottomNav active="payment" />
      </div>
    </div>
  );
}