import React, { useEffect, useMemo, useState } from "react";
import { Ticket as TicketIcon } from "lucide-react";
import { format, parseISO, isSameDay } from "date-fns";
import { ru } from "date-fns/locale";
import BottomNav from "@/components/BottomNav";

const STORAGE_KEY = "my-ticket-history";

function loadTickets() {
  try {
    const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}

export default function History() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTickets(loadTickets());
    setLoading(false);
  }, []);

  const grouped = useMemo(() => {
    const map = new Map();
    for (const ticket of tickets) {
      const d = new Date(ticket.purchase_time);
      if (Number.isNaN(d.getTime())) continue;
      const key = format(d, "yyyy-MM-dd");
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(ticket);
    }
    return Array.from(map.entries()).map(([key, items]) => ({
      key,
      date: new Date(items[0].purchase_time),
      items,
    }));
  }, [tickets]);

  const dateLabel = (d) => {
    const now = new Date();
    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);
    if (isSameDay(d, now)) return "Сегодня";
    if (isSameDay(d, yesterday)) return "Вчера";
    return format(d, "d MMMM", { locale: ru });
  };

  return (
    <div className="min-h-[100dvh] bg-[#f5f4fe] flex flex-col overflow-hidden">
      <header className="px-5 pt-6 pb-3 bg-[#f5f4fe] sticky top-0 z-10">
        <h1 className="text-2xl font-bold text-[#333333]">История</h1>
      </header>

      <main className="relative flex-1 overflow-y-auto px-4 pb-44">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -bottom-20 -left-24 h-72 w-72 rounded-full bg-[#e5e2ff] blur-3xl opacity-70" />
          <div className="absolute -bottom-10 -right-24 h-80 w-80 rounded-full bg-[#e5e2ff] blur-3xl opacity-60" />
        </div>

        <div className="relative z-10">
          {loading ? (
            <div className="flex justify-center py-16"><div className="w-7 h-7 border-4 border-violet-200 border-t-violet-600 rounded-full animate-spin" /></div>
          ) : tickets.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-24 text-center">
              <div className="mb-5 flex h-20 w-20 items-center justify-center rounded-[24px] bg-gradient-to-br from-violet-600 to-orange-400 shadow-lg shadow-violet-300/40">
                <TicketIcon className="h-10 w-10 text-white" strokeWidth={1.8} />
              </div>
              <h2 className="text-base font-semibold text-[#333333] mb-1">История пуста</h2>
              <p className="text-sm text-[#777777]">Купленные билеты появятся здесь</p>
            </div>
          ) : (
            grouped.map((group) => (
              <div key={group.key} className="mb-5">
                <h3 className="text-sm font-medium text-[#888888] mb-2 px-1">{dateLabel(group.date)}</h3>
                <div className="space-y-2.5">
                  {group.items.map((t, index) => {
                    const d = new Date(t.purchase_time);
                    return (
                      <div key={t.id || `${group.key}-${index}`} className="flex items-center gap-3 rounded-2xl bg-white p-3.5 shadow-sm shadow-violet-100/40">
                        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-violet-50">
                          <TicketIcon className="h-6 w-6 text-violet-500" strokeWidth={1.8} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-[#333333] leading-tight">{t.transport_type || "Автобус"} №{t.route_number || "—"}</p>
                          <p className="text-xs text-[#999999] mt-0.5">{format(d, "HH:mm:ss")}</p>
                        </div>
                        <span className="font-bold text-[#333333] text-sm whitespace-nowrap">{t.quantity || 1} шт</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>
      </main>

      <div className="fixed inset-x-0 bottom-0 z-20">
        <div className="px-5 pb-3 pt-1 bg-gradient-to-t from-[#f5f4fe] via-[#f5f4fe] to-transparent">
          <button className="w-full rounded-2xl bg-gradient-to-r from-violet-600 to-orange-400 py-4 text-center text-sm font-bold tracking-wide text-white shadow-lg shadow-violet-300/40 active:scale-[0.98] transition-transform">КУПИТЬ БИЛЕТ</button>
        </div>
        <BottomNav active="history" />
      </div>
    </div>
  );
}
