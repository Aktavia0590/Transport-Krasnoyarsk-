import React, { useEffect, useState } from "react";
import { Settings, Info, FileText, LogOut, MapPin, Info as InfoIcon } from "lucide-react";
import BottomNav from "@/components/BottomNav";

const menuItems = [
  { label: "Настройки", icon: Settings },
  { label: "О приложении", icon: Info },
  { label: "Пользовательское соглашение", icon: FileText },
];

export default function Menu() {
  const [email, setEmail] = useState("—");

  useEffect(() => {
    try {
      const saved = localStorage.getItem("my-ticket-email");
      if (saved) setEmail(saved);
    } catch {}
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("my-ticket-email");
    setEmail("—");
  };

  return (
    <div className="min-h-[100dvh] bg-[#f0f0ff] flex flex-col overflow-hidden">
      <main className="relative flex-1 overflow-y-auto pb-24">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -top-16 -right-24 h-64 w-64 rounded-full bg-[#e8e7f5] blur-3xl opacity-70" />
          <div className="absolute bottom-0 -left-24 h-72 w-72 rounded-full bg-[#e8e7f5] blur-3xl opacity-60" />
        </div>

        <div className="relative z-10 px-4 pt-4">
          <div className="rounded-3xl bg-gradient-to-r from-pink-500 to-orange-500 p-5 shadow-lg shadow-pink-200/50">
            <div className="flex items-start justify-between">
              <div className="min-w-0">
                <p className="text-white font-medium text-base truncate">{email}</p>
                <div className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-white/25 backdrop-blur px-3 py-1.5">
                  <MapPin className="h-3.5 w-3.5 text-white" strokeWidth={2.2} />
                  <span className="text-white text-xs font-medium">Красноярский край</span>
                </div>
              </div>
              <button className="shrink-0 rounded-full p-1.5 hover:bg-white/10 transition-colors">
                <InfoIcon className="h-5 w-5 text-white" strokeWidth={2} />
              </button>
            </div>
          </div>

          <div className="mt-5 space-y-1">
            {menuItems.map(({ label, icon: Icon }) => (
              <button key={label} className="flex w-full items-center gap-4 rounded-2xl px-2 py-3.5 text-left hover:bg-white/50 transition-colors">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-100"><Icon className="h-5 w-5 text-violet-600" strokeWidth={2} /></div>
                <span className="font-medium text-[#333333]">{label}</span>
              </button>
            ))}

            <button onClick={handleLogout} className="flex w-full items-center gap-4 rounded-2xl px-2 py-3.5 text-left hover:bg-white/50 transition-colors">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-100"><LogOut className="h-5 w-5 text-violet-600" strokeWidth={2} /></div>
              <span className="font-medium text-[#333333]">Выйти</span>
            </button>
          </div>
        </div>
      </main>

      <div className="fixed inset-x-0 bottom-0 z-20"><BottomNav active="menu" /></div>
    </div>
  );
}
