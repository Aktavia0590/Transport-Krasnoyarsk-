import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Ticket } from "lucide-react";
import BottomNav from "@/components/BottomNav";

export default function Home() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("ticket");

  return (
    <div className="min-h-[100dvh] bg-[#f9faff] flex flex-col overflow-hidden">
      <header className="px-5 pt-6 pb-2">
        <h1 className="text-xl font-bold text-[#333333]">Мой билет</h1>
      </header>

      <main className="relative flex-1 flex flex-col items-center justify-center px-6 overflow-hidden">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -top-10 -left-16 h-56 w-56 rounded-full bg-[#ebebff] blur-3xl opacity-80" />
          <div className="absolute top-24 -right-20 h-64 w-64 rounded-full bg-[#ebebff] blur-3xl opacity-70" />
          <div className="absolute bottom-10 left-1/4 h-48 w-48 rounded-full bg-[#ebebff] blur-3xl opacity-60" />
        </div>

        <div className="relative z-10 flex flex-col items-center text-center max-w-xs">
          <div className="mb-7 flex h-24 w-24 items-center justify-center rounded-[28px] bg-gradient-to-br from-violet-600 to-orange-400 shadow-lg shadow-violet-300/40">
            <Ticket className="h-12 w-12 text-white" strokeWidth={1.8} />
          </div>
          <h2 className="text-lg font-semibold text-[#333333] mb-2">
            Нет действующего билета
          </h2>
          <p className="text-sm leading-relaxed text-[#777777]">
            Для покупки билета нажмите кнопку внизу экрана
          </p>
        </div>
      </main>

      <div className="relative z-10 px-5 pb-4">
        <button
          onClick={() => navigate("/scan")}
          className="w-full rounded-2xl bg-gradient-to-r from-violet-600 to-orange-400 py-4 text-center text-sm font-bold tracking-wide text-white shadow-lg shadow-violet-300/40 active:scale-[0.98] transition-transform"
        >
          КУПИТЬ БИЛЕТ
        </button>
      </div>

      <BottomNav active={activeTab} onChange={setActiveTab} />
    </div>
  );
}