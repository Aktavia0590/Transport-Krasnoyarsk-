import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Zap } from "lucide-react";

const STORAGE_KEY = "my-ticket-history";

function saveTicket(routeNumber = "—") {
  try {
    const current = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    const ticket = {
      id: `${Date.now()}`,
      transport_type: "Автобус",
      route_number: routeNumber,
      purchase_time: new Date().toISOString(),
      quantity: 1,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify([ticket, ...current].slice(0, 200)));
  } catch {}
}

export default function Scan() {
  const navigate = useNavigate();
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const detectorRef = useRef(null);
  const timerRef = useRef(null);
  const [torchOn, setTorchOn] = useState(false);
  const [torchSupported, setTorchSupported] = useState(false);
  const [cameraError, setCameraError] = useState(false);
  const [scanning, setScanning] = useState(true);

  useEffect(() => {
    let active = true;

    const start = async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error("Camera API unavailable");

        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: "environment" } },
          audio: false,
        });

        if (!active) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }

        streamRef.current = stream;
        if (videoRef.current) videoRef.current.srcObject = stream;

        const track = stream.getVideoTracks()[0];
        const caps = track?.getCapabilities?.() || {};
        if (caps.torch) setTorchSupported(true);

        if ("BarcodeDetector" in window) {
          try {
            const detector = new window.BarcodeDetector({ formats: ["qr_code"] });
            detectorRef.current = detector;

            const scan = async () => {
              if (!active || !videoRef.current || videoRef.current.readyState < 2 || !scanning) return;
              try {
                const codes = await detector.detect(videoRef.current);
                if (codes.length) {
                  setScanning(false);
                  saveTicket(codes[0].rawValue || "—");
                  navigate("/");
                  return;
                }
              } catch {}
              timerRef.current = setTimeout(scan, 300);
            };
            timerRef.current = setTimeout(scan, 500);
          } catch {}
        }
      } catch {
        if (active) setCameraError(true);
      }
    };

    start();

    return () => {
      active = false;
      if (timerRef.current) clearTimeout(timerRef.current);
      if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    };
  }, [navigate, scanning]);

  const toggleTorch = async () => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return;
    try {
      const next = !torchOn;
      await track.applyConstraints({ advanced: [{ torch: next }] });
      setTorchOn(next);
    } catch {}
  };

  return (
    <div className="fixed inset-0 z-50 bg-black select-none">
      <video ref={videoRef} autoPlay playsInline muted className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-black/60" />

      <div className="absolute top-0 inset-x-0 flex items-center px-4 pt-[calc(env(safe-area-inset-top)+1rem)] pb-3">
        <button onClick={() => navigate("/")} className="flex h-10 w-10 items-center justify-center rounded-full bg-black/30 backdrop-blur active:scale-95 transition-transform">
          <ArrowLeft className="h-6 w-6 text-white" strokeWidth={2.2} />
        </button>
        <h1 className="absolute left-1/2 -translate-x-1/2 text-white font-semibold text-lg">Сканирование QR</h1>
      </div>

      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="relative h-64 w-64">
          <div className="absolute inset-0 rounded-2xl border-2 border-white/40" />
          <div className="absolute -top-0.5 -left-0.5 h-10 w-10 rounded-tl-2xl border-l-[5px] border-t-[5px] border-white" />
          <div className="absolute -top-0.5 -right-0.5 h-10 w-10 rounded-tr-2xl border-r-[5px] border-t-[5px] border-white" />
          <div className="absolute -bottom-0.5 -left-0.5 h-10 w-10 rounded-bl-2xl border-l-[5px] border-b-[5px] border-white" />
          <div className="absolute -bottom-0.5 -right-0.5 h-10 w-10 rounded-br-2xl border-r-[5px] border-b-[5px] border-white" />
        </div>
        <p className="mt-6 text-center text-white font-medium text-base px-8">Наведите камеру на QR-код</p>
        {cameraError && <p className="mt-2 text-center text-white/70 text-sm px-8">Не удалось получить доступ к камере</p>}
      </div>

      <div className="absolute bottom-0 inset-x-0 flex justify-center pb-[calc(env(safe-area-inset-bottom)+2rem)]">
        <button onClick={toggleTorch} disabled={!torchSupported} className={`flex h-14 w-14 items-center justify-center rounded-full backdrop-blur transition-colors ${torchOn ? "bg-white/90" : "bg-black/40"} ${!torchSupported ? "opacity-40" : "active:scale-95"}`}>
          <Zap className={`h-6 w-6 ${torchOn ? "text-black" : "text-white"}`} strokeWidth={2.2} fill={torchOn ? "currentColor" : "none"} />
        </button>
      </div>
    </div>
  );
}
