export const base44 = {
  auth: {
    async me() { return null; },
    async logout() { return true; },
  },
  entities: {
    Ticket: {
      async list() { return []; },
    },
  },
};
