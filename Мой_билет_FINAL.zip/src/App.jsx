import React, { useState } from "react";
import Home from "./pages/Home";
import History from "./pages/History";
import Payment from "./pages/Payment";
import Menu from "./pages/Menu";
import Scan from "./pages/Scan";

function ErrorScreen({ error }) {
  return (
    <div style={{minHeight:"100dvh",display:"flex",alignItems:"center",justifyContent:"center",padding:24,textAlign:"center",fontFamily:"system-ui"}}>
      <div>
        <h2>Не удалось открыть экран</h2>
        <p style={{color:"#777",wordBreak:"break-word"}}>{error?.message || "Неизвестная ошибка"}</p>
        <button onClick={() => window.location.reload()} style={{padding:"12px 20px",border:0,borderRadius:12,background:"#111",color:"white"}}>Перезапустить</button>
      </div>
    </div>
  );
}

class Boundary extends React.Component {
  state = { error: null };
  static getDerivedStateFromError(error) { return { error }; }
  render() { return this.state.error ? <ErrorScreen error={this.state.error} /> : this.props.children; }
}

export default function App() {
  const [screen, setScreen] = useState("home");

  const go = (name) => setScreen(name);

  return (
    <Boundary>
      {screen === "home" && <Home onNavigate={go} />}
      {screen === "history" && <History onNavigate={go} />}
      {screen === "payment" && <Payment onNavigate={go} />}
      {screen === "menu" && <Menu onNavigate={go} />}
      {screen === "scan" && <Scan onNavigate={go} />}
    </Boundary>
  );
}
