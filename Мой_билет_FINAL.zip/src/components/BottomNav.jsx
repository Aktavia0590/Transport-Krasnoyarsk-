import React from "react";
import { Ticket, History as HistoryIcon, CreditCard, Menu as MenuIcon } from "lucide-react";

const items = [
  { key: "home", label: "Мой билет", icon: Ticket },
  { key: "history", label: "История", icon: HistoryIcon },
  { key: "payment", label: "Оплата", icon: CreditCard },
  { key: "menu", label: "Меню", icon: MenuIcon },
];

export default function BottomNav({ active, onNavigate }) {
  return (
    <nav className="bg-white/90 backdrop-blur-lg border-t border-slate-100 pb-[env(safe-area-inset-bottom)]">
      <div className="flex items-stretch justify-around px-2 pt-2 pb-1.5">
        {items.map(({ key, label, icon: Icon }) => {
          const isActive = active === key;
          return (
            <button key={key} type="button" onClick={() => onNavigate(key)} className="flex flex-col items-center gap-1 flex-1 py-1.5 rounded-xl">
              <Icon className={`h-6 w-6 ${isActive ? "text-violet-600" : "text-slate-400"}`} strokeWidth={isActive ? 2.4 : 2} />
              <span className={`text-[11px] leading-none ${isActive ? "text-violet-600 font-semibold" : "text-slate-400"}`}>{label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
