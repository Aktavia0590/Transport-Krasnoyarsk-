import React, { useEffect, useRef, useState } from "react";
import { ArrowLeft, Zap } from "lucide-react";

export default function Scan({ onNavigate }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const [torchOn, setTorchOn] = useState(false);
  const [torchSupported, setTorchSupported] = useState(false);
  const [cameraError, setCameraError] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment" },
          audio: false,
        });
        if (!active) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) videoRef.current.srcObject = stream;
        const track = stream.getVideoTracks()[0];
        const caps = track.getCapabilities ? track.getCapabilities() : {};
        if (caps.torch) setTorchSupported(true);
      } catch (e) {
        if (active) setCameraError(true);
      }
    })();
    return () => {
      active = false;
      if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const toggleTorch = async () => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return;
    try {
      const next = !torchOn;
      await track.applyConstraints({ advanced: [{ torch: next }] });
      setTorchOn(next);
    } catch (e) {}
  };

  return (
    <div className="fixed inset-0 z-50 bg-black select-none">
      <video ref={videoRef} autoPlay playsInline muted className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-black/60" />

      <div className="absolute top-0 inset-x-0 flex items-center px-4 pt-[calc(env(safe-area-inset-top)+1rem)] pb-3">
        <button onClick={() => onNavigate("home")} className="flex h-10 w-10 items-center justify-center rounded-full bg-black/30 backdrop-blur active:scale-95 transition-transform">
          <ArrowLeft className="h-6 w-6 text-white" strokeWidth={2.2} />
        </button>
        <h1 className="absolute left-1/2 -translate-x-1/2 text-white font-semibold text-lg">Сканирование QR</h1>
      </div>

      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="relative h-64 w-64">
          <div className="absolute inset-0 rounded-2xl border-2 border-white/40" />
          <div className="absolute -top-0.5 -left-0.5 h-10 w-10 rounded-tl-2xl border-l-[5px] border-t-[5px] border-white" />
          <div className="absolute -top-0.5 -right-0.5 h-10 w-10 rounded-tr-2xl border-r-[5px] border-t-[5px] border-white" />
          <div className="absolute -bottom-0.5 -left-0.5 h-10 w-10 rounded-bl-2xl border-l-[5px] border-b-[5px] border-white" />
          <div className="absolute -bottom-0.5 -right-0.5 h-10 w-10 rounded-br-2xl border-r-[5px] border-b-[5px] border-white" />
        </div>
        <p className="mt-6 text-center text-white font-medium text-base px-8">Наведите камеру на QR-код</p>
        {cameraError && (
          <p className="mt-2 text-center text-white/70 text-sm px-8">Не удалось получить доступ к камере</p>
        )}
      </div>

      <div className="absolute bottom-0 inset-x-0 flex justify-center pb-[calc(env(safe-area-inset-bottom)+2rem)]">
        <button onClick={toggleTorch} disabled={!torchSupported}
          className={`flex h-14 w-14 items-center justify-center rounded-full backdrop-blur transition-colors ${torchOn ? "bg-white/90" : "bg-black/40"} ${!torchSupported ? "opacity-40" : "active:scale-95"}`}>
          <Zap className={`h-6 w-6 ${torchOn ? "text-black" : "text-white"}`} strokeWidth={2.2} fill={torchOn ? "currentColor" : "none"} />
        </button>
      </div>
    </div>
  );
}